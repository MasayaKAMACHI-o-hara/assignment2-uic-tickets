using UnityEngine;

public class KanMove : MonoBehaviour
{

    void Awake()
    {
        // FPSを480に固定する
        Application.targetFrameRate = 480;
    }

    public Rigidbody body;

    public Transform Camera;

    public float Speed = 0;

    public float JumpPower = 30;

    public bool isGrounded = true;

     

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKey(KeyCode.W))
        {
            if(Speed <= 3)
            {
                Speed += 0.05f;
            }
        }
        else if(Speed > 0)
        {
            Speed-= 0.05f;
        }

        if (Input.GetKey(KeyCode.S))
        {
            if (Speed >= -3)
            {
                Speed -= 0.05f;
            }
        }
        else if (Speed < 0)
        {
            Speed += 0.05f;
        }
        Vector3 rot = this.transform.eulerAngles;

        if (Input.GetKey(KeyCode.A))
        {
            // Y軸の数値に -0.5
            rot.y -= 0.5f;

            // オブジェクトに反映
            transform.eulerAngles = rot;

        }

        if (Input.GetKey(KeyCode.D))
        {
            // Y軸の数値に +0.5
            rot.y += 0.5f;

            // オブジェクトに反映
            transform.eulerAngles = rot;

        }

        if (Input.GetKeyDown(KeyCode.Space) && isGrounded)
        {
            body.AddForce(Vector3.up * JumpPower, ForceMode.Impulse);
            isGrounded = false; // ジャンプした瞬間にフラグを下ろす
        }
            // カメラの正面方向を取得
            Vector3 forward = Camera.forward;

        // 上下の向き（Y軸）を無視して、水平方向にだけ進むように調整
        forward.y = 0;
        forward = forward.normalized;


        this.body.AddForce(forward * Speed);
    }
    // 地面に触れた瞬間に呼ばれる
    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground"))//もしGroundというTagがついているものに触れたら、
        {
            isGrounded = true;//ジャンプをできるようにする。
        }
    }
}
